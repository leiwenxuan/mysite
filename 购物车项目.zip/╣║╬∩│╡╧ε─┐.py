# -*- coding: utf-8 -*-
# @Time    : 2018/8/10/010 19:07
# @Author  : LeiWenXuan
# @Email   : 892028617@qq.com
# @File    : 购物车项目.py
# @Software: PyCharm
# import xlrd
# import xlwt
import  os
# from datetime import date,datetime
# Flag_ON = True #如果有xlrd xlwt 两个库则不用改变Flag_ON  否则改为False
# # Flag_ON = False
#     #参数： 读取文件那个纵行
#     #Return: 返回纵排列表
# def read_excel_rols(colsx):
#     work_book = xlrd.open_workbook(r'LOL.xls') #读取LOL.xls文件
#     # print(work_book.sheet_names())
#     # sheet_1 = work_book.sheet_names()[0]
#     # print(sheet_1)
#     sheet2 = work_book.sheet_by_index(0) # 返回那一个sheet
#     # sheet2 = work_book.sheet_names('Sheet2')
#     # print(sheet2)
#     # print(sheet2.name, sheet2.nrows,sheet2.ncols) #name 代表Sheet nrows 行排参数 ncols 纵排参数
#     # rows = sheet2.row_values(1)  #返回一行的所有参数 ['蛮王', 3999.0]
#
#
#     cols1 = sheet2.col_values(colsx) #读取文件竖排 返回列表形式['name', '蛮王', '瑞文', '寒冰', '赵云']
#     # cols2 = sheet2.col_values(1) #读取文件竖排 参数代表那个竖排
#     return cols1
# # print(read_excel_rols(0))
#
#
# def Get_MyGoods():
#     goods1 = []
#     name = read_excel_rols(0)
#     price = read_excel_rols(1)
#     for i in range(1,len(name)):
#         #在列表里面创建字典
#         #原有字典['name', '蛮王', '瑞文', '寒冰', '赵云']
#                 # ['price', 3999.0, 7499.0, 199.0, 3500.0]
#         #把列表首元素作为键，其他元素作为值，
#         goods1.append({name[0]:name[i],price[0]:int(price[i])})
#     return goods1
# if Flag_ON:
#     goods = Get_MyGoods()
# else:
goods = [{"name": "电脑", "price": 1999},
         {"name": "鼠标", "price": 10},
         {"name": "游艇", "price": 20},
         {"name": "美女", "price": 998}, ]

# 1. 用户先给自己的账户充钱：比如先充3000元。money = input('充钱..')
# 2. 页面显示 序号 + 商品名称 + 商品价格，如：
# 3. 用户输入选择的商品序号，然后打印商品名称及商品价格,并将此商品，添加到购物车，用户还可继续添加商品。
# 4. 如果用户输入的商品序号有误，则提示输入有误，并重新输入。
# {'name':[1,2,]}
# 5. 用户输入n为购物车结算，依次显示用户购物车里面的商品，数量及单价，若充值的钱数不足，则让用户删除某商品，
# 直至可以购买，若充值的钱数充足，则可以直接购买。
# 6. 用户输入Q或者q退出程序。
# 7. 退出程序之后，依次显示用户购买的商品，数量，单价，以及此次共消费多少钱，账户余额多少。
Moeney = 0 #初始金额
balance = 0 #结算金额
shopping_car = {} #购物车详单

flag = True
Buy_ON = False


def check(choice):
    ''' 添加金币模块'''
    while 1:
        if choice.isdigit():
            return int(choice)
        else:
            choice = input("\033[32;0m请输入正确的数据！\033[0m")

def Shop_del():
    global balance
    delmoney = 0
    while 1:
        print('\033[35;0m你购物车的物品如下')

        for index ,dic in shopping_car.items():
            print('序号：{}---{}---{}---{}'.format(dic[2], index, dic[0],dic[1]))
            # print(index,dic)
        print('你现在有金币%s，够买此次购物车的物品一共%s'%(Moeney,balance ))
        if Moeney > balance:
            print("你的金币足够支付购物车物品")
        else:
            print('金币还不够支付购物车物品')
        if bool(shopping_car):
            print('\033[0m ')
            rem = input('\033[32;0m 请输入要删除的元素！》》或者按【Q】退出删除：\033[0m ')

        else:
            balance = 0
            print("购物车空空如也！,自动返回购物车选择！")
            break
        if rem.isdigit():
            select = int(rem)
            # select = shopping_car[select]
            # if 0 < select < len(shopping_car)+1:
            if bool(shopping_car):#如果为空列表则不进去
                # print(shopping_car)
                #和加操作一样不过，列表第三位记住了添加物品在原数据的序号 找到对应物品进行删除
                if shopping_car.get(goods[select-1]['name']):
                    if shopping_car[goods[select-1]['name']][1] > 0:
                        print('你删除的商品---{}---{}'.format(goods[select - 1]['name'], goods[select - 1]["price"]))
                        shopping_car[goods[select-1]['name']][1] -= 1
                        balance -= shopping_car[goods[select-1]['name']][0]

                        print(shopping_car[goods[select-1]['name']][0])
                        if shopping_car[goods[select-1]['name']][1] == 0:
                            shopping_car.pop(goods[select-1]['name'],'已删除')

                    else:
                        print(shopping_car.get(goods[select-1]['name'],'没有删除的商品'))

                else:
                    print('你要删除的物品序号不存在')
                    # shopping_car[goods[select-1]['name']] = [goods[select-1]["price"],1]
            else:
                print("购物车空空如也！")
        elif rem.upper() == 'Q':
            break
#引入文件操作获取文件的信息并且制作成列表
#第12题写一个函数完成三次登陆功能：(升级题,两天做完)
import fileinput
def RingUp():
    with open('register.txt',mode='r', encoding='utf-8') as fw:
        user_dic = {}
        for line in fw:
            line = line.strip().split('|')
            user_dic.setdefault(line[0], line[1])
        print(user_dic)
        count = 0
        print('请登录账号！')
        while 1:
            username = input('请输入你的账户：》》')
            passworld = input('请输入你的密码：》》')
            if username in user_dic and passworld == user_dic[username]:

                    return 1,username,passworld
            else:
                print('密码或账户错误！')
                count += 1
            if count == 3:
                # Newpassworld = input('请修改你的密码：》》')
                # #密码修改功能
                # with open('register.txt', mode='w', encoding='utf-8') as fw:
                #     print(user_dic)
                #     for key,val in user_dic.items():
                #         if username == key:
                #              val = Newpassworld
                #         fw.write('{}|{}\n'.format(key,val))
                #         print('密码修改成功！')
                return False
# RingUp()


#13，再写一个函数完成注册功能：(升级题,两天做完)
def Register():
    sel = input("如有账号按【Q】退出注册,任意键继续注册》》")
    if sel.upper() == 'Q':
        return True
    with open('register.txt', mode='r', encoding='utf-8') as fw:
        user_dic = {}
        for line in fw:
            line = line.strip().split('|')
            user_dic.setdefault(line[0], line[1])
        print(user_dic)
        Flag_username = True
    while 1:
        if Flag_username:username = input('请输入你的用户名:>>').strip()
        if username.isalnum():
            if username in user_dic:
                print('用户名已存在！请重新输入！')
            else:
                passworld = input('请输入你的密码:>>').strip()
                if len(passworld) < 14:
                    # print('注册成功！')
                    with open('register.txt', mode='a') as f2:
                        f2.write('{}|{}\n'.format(username, passworld))
                        return True
                else:
                    print('密码过长！')
                    Flag_username = False

        else:print('你的输入中有非法字符！')


def Back_up():
    '''获取获取用户姓名，匹配数据，没有则给用户创建数据'''
    lis_dir_file = os.listdir()
    if My_file_buy in lis_dir_file:
        print('你有购买的过商品清单！')
    else:
        with open(My_file_buy, mode='w', encoding='utf-8') as fb:
            pass
    if My_file_want in lis_dir_file:
        print("你有想购物的清单！")
    else:
        with open(My_file_want, mode='w', encoding='utf-8') as fw:
            pass

def File_mode(myfile):
    with open(myfile,mode='r', encoding='utf-8') as fr,\
            open(myfile+'.bak', mode='w', encoding='utf-8') as fw:
        if shopping_car:
            for line in fr:
                # print(shopping_car)
                # print(line)
                if line.strip():
                    line = line.strip().split('|')
                    shopping_car.setdefault(line[0],[line[1],int(line[2]), line[3]])
                    print(shopping_car)
                    shopping_car[line[0]][1] += int(line[2])
            for keys, vals in shopping_car.items():
                for i, j in enumerate(vals):
                    vals[i] = str(j)
                    # print(i, j)
                fw.write('{}|{}\n'.format(keys, '|'.join(vals)))
        os.remove(myfile)
        os.rename(myfile+'.bak', myfile)


def Select_N():
    global Moeney
    global balance
    global Buy_ON
    if bool(shopping_car):
        print('\033[35;0m你购物车的物品如下')
        for key, val in shopping_car.items():
            print('{}  {} X {}'.format(key, val[0], val[1]))
            balance += val[0] * val[1]
        # print('\033[0m你此次消费一共%s,你共有金币%s 请选择支付'%(balance,Moeney))
        while balance >= Moeney and bool(shopping_car):
            # for val in shopping_car.values():
            #     print(shopping_car)
            #     balance += val[0] * val[1]
            balance = 0  # 重置为0是下面打印列表时候重新计算
            print('\033[35;0m你购物车的物品如下')
            for key, val in shopping_car.items():
                print('{}  {} X {}'.format(key, val[0], val[1]))
                balance += val[0] * val[1]
            print('\033[0m你此次消费一共%s,你共有金币%s 请选择支付' % (balance, Moeney))
            # print('你一共有%s金币，购买此次物品需要%s'%(Moeney,balance))
            print('你的金币不足，请选择【del】删除物品，选择【add】充值金币')
            st = input("请输入你的选择》》")
            if st.upper() == 'DEL':
                Shop_del()
                balance = 0
                for val in shopping_car.values():
                    balance += val[0] * val[1]
            elif st.upper() == 'ADD':
                M = input("请输入增加的金币数》》")
                Moeney += check(M)
                print("现在有金币：%s" % (Moeney))
        if balance <= Moeney:
            Yes_no = input('你的金币已经足够购买商品请问现在购买吗？\n'
                           '输入【yes】购买\n'
                           '输入任意键继续购物')
            if Yes_no.isalpha():
                if Yes_no.upper() == 'YES':
                    Buy_ON = True
                    print('您这次共花费{}，还剩下{}金币，欢迎下次光临！'.format(balance, Moeney - balance))
                    balance = 0
                    File_mode(My_file_buy)
                    shopping_car.clear()
                    return False
                else:
                    balance = 0
                    print('请继续购物！')
                    return True
    else:
        print("\033[1;32;41m你的购物车空空如也！\033[0m")
        return True

def Select_Yes():
    File_mode(My_file_want)
    if bool(shopping_car):
        print("此次购物共花费%s金币！" % (balance))
        if Buy_ON:
            print('你此次购物清单如下所示！')
            for keys, val in shopping_car.items():
                # print(keys,val)
                print('序号：{}---{}---{}'.format(val[2], keys, val[1]))
        else:
            print("你的购物车还有如下清单没有买！")
            for keys, val in shopping_car.items():
                print('序号：{}---{}---{}'.format(val[2], keys, val[1]))
        return False
    else:
        print("购物车空空如也，你甘心退出吗啊？")
        if input("输入【N】继续任意键退出系统！").upper() == 'N':
            return True
        else:
            return False
def Shop_add(select):
    if 0 < select < len(goods) + 1:
        # goods 是个列表内部由字典组成 goods[select-1]['name'] 代表电脑 oods[select-1]["price"]代表价格
        print('你添加的商品---{}---{}'.format(goods[select - 1]['name'], goods[select - 1]["price"]))
        if shopping_car.get(goods[select - 1]['name']):  # 如果找在shopping_car.get()类似物品没有找的话else去添加
            # shopongoing是[{"name":[]}]
            shopping_car[goods[select - 1]['name']][1] += 1  # 在shop的字典列表的第二位元素累加一
        else:
            # 创建[{"name":[]}]类型初始化数据，用赋值添加字典的方式给字典加个列表【1】表示物品出现第一次 select记住物品的编号便于删除查找
            # goods[select-1]['name']找到物品的名字
            shopping_car[goods[select - 1]['name']] = [goods[select - 1]["price"], 1, select]
    else:
        print("\033[31;0m你选择的序号不正确！\033[0m")

def Check_buy():
    shopping_car_buy = {}
    with open(My_file_buy, mode='r', encoding='utf-8') as f:
        for line in f:
            line = line.strip().split('|')
            print('\033[32;0m序号：{}-{}-价格:{}数量:{}\033[0m'.format(line[3], line[0],line[1],line[2] ))

def check_want_buy():
    with open(My_file_want, mode='r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                line = line.strip().split('|')
                shopping_car.setdefault(line[0], [int(line[1]), int(line[2]), int(line[3])])
                shopping_car[line[0]][1] +=int(line[2])
            else:
                print('购物车没有添加任何商品！')
    print('购物车商品如下')
    for keys,val in shopping_car.items():
        print('\033[32;0m序号：{}-{}-价格:{}数量:{}\033[0m'.format(val[2], keys, val[0], val[1]))


Register() #
flag, Myname, Myworld = RingUp()

Moeney = input("请你先充值金币，方便付款>>:")
Moeney = check(Moeney)

#定义用户文件
My_file_buy = Myname + '_buy_goods.txt'
My_file_want = Myname + '_want_buy.txt'
Back_up()

while flag:
    print(Myname, Myworld)
    for index,dic in enumerate(goods,1):
        # 格式化输出
        print('序号：{}---{}---{}'.format(index, dic['name'], dic['price']))
    select = input("\033[33;0m请输入的你的选择》》》：\033[0m")
    if select.isdigit(): #检查输出的是不是数字
        select = int(select)
        Shop_add(select)
    elif select.upper() == 'Q':
        flag = Select_Yes()
    elif select.upper() == 'N':
        flag = Select_N()
    elif select.upper() == 'C':
        '''查看已购买的物品'''
        Check_buy()
        pass
    elif select.upper() == 'R':
        '''想买的物品 '''
        check_want_buy()
        pass
    else:
        print('\033[1;32;40m你输入的选择不正确请重新输入\033[0m ')